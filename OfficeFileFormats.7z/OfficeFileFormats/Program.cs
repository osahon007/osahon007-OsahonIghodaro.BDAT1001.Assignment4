﻿/*
using System;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OfficeFileFormats.Models;
using OfficeFileFormats.Models.Utilities;

namespace OfficeFileFormats
{
    class Program
    {
        static void Main(string[] args)
        
        //ASSIGNMENT NO - 1a
        {
           // Create a document by supplying the filepath. 
           using (var doc =
           WordprocessingDocument.Create(@"C:\Users\Admin\Desktop\Student Files\info.docx", WordprocessingDocumentType.Document))
           {
           // Add a main document part. 
           MainDocumentPart mainPart = doc.AddMainDocumentPart();

           // Create the document structure and add some text.
           mainPart.Document = new DocumentFormat.OpenXml.Wordprocessing.Document();

           Body body = mainPart.Document.AppendChild(new Body());
           Paragraph para = body.AppendChild(new Paragraph());
           Run run = para.AppendChild(new Run());
           run.AppendChild(new Text("Hello, my name is Osahon Ighodaro"));




           }
           //ASSIGNMENT NO - 1d
           string localUploadFilePath = @"C:\Users\Admin\Desktop\Student Files\info.docx";
           string remoteUploadFileDestination = "/200470130 Osahon Ighodaro/info.docx";
           Console.WriteLine(FTP.UploadFile(localUploadFilePath, Constants.FTP.BaseUrl + remoteUploadFileDestination));
        }

       
        
    }
}

*/


/*
using Microsoft.Office.Interop.PowerPoint;
using OfficeFileFormats.Models.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficeFileFormats.Models;

namespace OfficeXMLPowerPoint
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //ASSIGNMENT NO - 3a
            string[] PictureFile = { @"C:\Users\Admin\Desktop\myimage.jpeg", @"C:\Users\Admin\Desktop\Class Exercise\FTPApp2\Contents\Images\200335615 Chris Dyck.jpg", @"C:\Users\Admin\Desktop\Class Exercise\FTPApp2\Contents\Images\083100937 Leah Stepanek.jpg" };
            Application pptApplication = new Application();
            Presentation pptpresentation = pptApplication.Presentations.Add(Microsoft.Office.Core.MsoTriState.msoTrue);

            for (int i = 0; i < PictureFile.Length; i++)

            {
                Microsoft.Office.Interop.PowerPoint.Slides slides;
                Microsoft.Office.Interop.PowerPoint._Slide slide;
                Microsoft.Office.Interop.PowerPoint.TextRange objText;

                Microsoft.Office.Interop.PowerPoint.CustomLayout custLayout =
                    pptpresentation.SlideMaster.CustomLayouts[Microsoft.Office.Interop.PowerPoint.PpSlideLayout.ppLayoutText];

                slides = pptpresentation.Slides;
                slide = slides.AddSlide(i + 1, custLayout);

                objText = slide.Shapes[1].TextFrame.TextRange;
                objText.Text = "Hello, my name is Osahon Ighodaro" + i;
                objText.Font.Name = "Arial";
                objText.Font.Size = 32;

                Microsoft.Office.Interop.PowerPoint.Shape shape = slide.Shapes[2];
                slide.Shapes.AddPicture(PictureFile[i],
                    Microsoft.Office.Core.MsoTriState.msoFalse,
                    Microsoft.Office.Core.MsoTriState.msoTrue,
                    shape.Left, shape.Top, shape.Width, shape.Height);

            }

            pptpresentation.SaveAs(@"C:\Users\Admin\Desktop\Student Files\info.ppt", Microsoft.Office.Interop.PowerPoint.PpSaveAsFileType.ppSaveAsDefault, Microsoft.Office.Core.MsoTriState.msoTrue);

            
            //ASSIGNMENT NO - 3d
            string localUploadFilePath = @"C:\Users\Admin\Desktop\Student Files\info.ppt";
            string remoteUploadFileDestination = "/200470130 Osahon Ighodaro/info.ppt";
            Console.WriteLine(FTP.UploadFile(localUploadFilePath, Constants.FTP.BaseUrl + remoteUploadFileDestination));
            
        }
    }
}

*/

//ASSIGNMENT 2a
//Ref:  https://www.geeksforgeeks.org/writing-to-excel-sheet-using-epplus-in-c-sharp/
using System;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Runtime.InteropServices;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.Office.Interop.Excel;
using OfficeFileFormats.Models.Utilities;
using OfficeFileFormats.Models;
using Constants = OfficeFileFormats.Models.Constants;

class Program
{
    static void Main(string[] args)
    {
        var Articles = new[]
        {
                new {
                    StudentCode = "200470130", FullName = "Osahon Ighodaro"
                },
                new {
                    StudentCode = "200289345", FullName = "Carolyn Knight"
                },
                new {
                    StudentCode = "200443749", FullName = "Binaya Gurung"
                },
                new {
                    StudentCode = "200449414", FullName = "Jiyoung Sohn"
                },
                new {
                    StudentCode = "200449869", FullName = "Sucheta Karande"
                },
                new {
                    StudentCode = "083100937", FullName = "Leah Stepanek"
                }
            };

        // Creating an instance 
        // of ExcelPackage 
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        var excel = new ExcelPackage();
        //ExcelPackage excel = new ExcelPackage();

        // name of the sheet 
        var workSheet = excel.Workbook.Worksheets.Add("Sheet1");
        var workSheet2 = excel.Workbook.Worksheets.Add("Sheet2");

        // setting the properties 
        // of the work sheet  
        workSheet.TabColor = System.Drawing.Color.Black;
        workSheet.DefaultRowHeight = 12;

        workSheet2.TabColor = System.Drawing.Color.Black;
        workSheet2.DefaultRowHeight = 12;

        // Setting the properties 
        // of the first row 
        workSheet2.Row(1).Height = 20;
        workSheet2.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        workSheet2.Row(1).Style.Font.Bold = true;

        // Header of the Excel sheet 
        workSheet2.Cells[1, 1].Value = "Student Id";
        workSheet2.Cells[1, 2].Value = "Student Code";
        workSheet2.Cells[1, 3].Value = "Full Name";

        workSheet.Cells[2, 1].Value = "Hello, my name is Osahon Ighodaro";

        // Inserting the article data into excel 
        // sheet by using the for each loop 
        // As we have values to the first row  
        // we will start with second row 
        int recordIndex = 2;

        foreach (var article in Articles)
        {
            workSheet2.Cells[recordIndex, 1].Value = (recordIndex - 1).ToString();
            workSheet2.Cells[recordIndex, 2].Value = article.StudentCode;
            workSheet2.Cells[recordIndex, 3].Value = article.FullName;
            recordIndex++;
        }

        // By default, the column width is not  
        // set to auto fit for the content 
        // of the range, so we are using 
        // AutoFit() method here.  
        workSheet2.Column(1).AutoFit();
        workSheet2.Column(2).AutoFit();
        workSheet2.Column(3).AutoFit();

        // file name with .xlsx extension  
        string p_strPath = @"C:\Users\Admin\Desktop\Student Files\info.xlsx";

        if (File.Exists(p_strPath))
            File.Delete(p_strPath);

        // Create excel file on physical disk  
        FileStream objFileStrm = File.Create(p_strPath);
        objFileStrm.Close();

        // Write content to excel file  
        File.WriteAllBytes(p_strPath, excel.GetAsByteArray());
        //Close Excel package 
        excel.Dispose();
        Console.ReadKey();


        //ASSIGNMENT NO - 2d
        string localUploadFilePath = @"C:\Users\Admin\Desktop\Student Files\info.xlsx";
        string remoteUploadFileDestination = "/200470130 Osahon Ighodaro/info.xlsx";
        Console.WriteLine(FTP.UploadFile(localUploadFilePath, Constants.FTP.BaseUrl + remoteUploadFileDestination));

    }
}
